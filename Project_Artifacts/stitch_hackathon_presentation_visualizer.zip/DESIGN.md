---
name: Atmospheric Intelligence Console
colors:
  surface: '#0e141d'
  surface-dim: '#0e141d'
  surface-bright: '#343944'
  surface-container-lowest: '#080e17'
  surface-container-low: '#161c25'
  surface-container: '#1a2029'
  surface-container-high: '#242a34'
  surface-container-highest: '#2f353f'
  on-surface: '#dde2f0'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dde2f0'
  inverse-on-surface: '#2b313b'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#44e2cd'
  on-secondary: '#003731'
  secondary-container: '#03c6b2'
  on-secondary-container: '#004d44'
  tertiary: '#ffc174'
  on-tertiary: '#472a00'
  tertiary-container: '#f59e0b'
  on-tertiary-container: '#613b00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#62fae3'
  secondary-fixed-dim: '#3cddc7'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005047'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0e141d'
  on-background: '#dde2f0'
  surface-variant: '#2f353f'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  metric-large:
    fontFamily: Space Grotesk
    fontSize: 44px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.02em
  metric-unit:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a high-precision, atmospheric observation and early-warning environment built for meteorologists, disaster response directors, and scientific analysts within the Ministry of Earth Sciences (MoES) and NCMRWF. The aesthetic fuses the calm, ethereal legibility of consumer weather design (such as Apple Weather and Samsung One UI) with the dense, mission-critical clarity of aviation flight decks and Bloomberg terminals.

The experience evokes composure under pressure, absolute empirical precision, and intellectual calm. The interface prioritizes quiet clarity: noisy grids and harsh lines are eliminated in favor of misty frosted layers, subtle atmospheric depth, and purposeful focal points. Warning cues are reserved strictly for anomalous phenomena and hazard levels, ensuring alert fatigue is eliminated and critical weather signals command immediate attention.

## Colors

The palette simulates the atmospheric gradient from the mesosphere down to sea level, utilizing a deep obsidian-zinc base infused with deep marine slate.

### Palette Architecture
- **Primary (`#38BDF8` - Calm Azure):** Applied to telemetry states, blend weights, high-confidence AI vectors, active navigation pills, and primary interactive elements.
- **Secondary (`#2DD4BF` - Misty Teal):** Denotes NWP-AI consensus nodes, moisture fluxes, atmospheric pressure contours, and normal operational baselines.
- **Tertiary (`#F59E0B` - Amber Watch):** Deployed for meteorological watch advisories, ensemble variance thresholds, and forecast drift warnings.
- **Hazard Accent (`#F43F5E` - Emergency Crimson):** Exclusively reserved for cyclonic intensification, flash flood triggers, severe convective alerts, and critical anomalies.
- **Neutral Canvas (`#0B111A` - Deep Stratosphere):** The foundational substrate across which all glass surfaces float. Secondary surfaces leverage `#121C2B` and `#1E293B` to maintain balanced contrast without stark pitch-black clipping.
- **Text & Telemetry:** Pure white (`#F8FAFC`) is used sparingly for headline metrics; primary readability relies on Ice Mist (`#E2E8F0`), muted telemetry relies on Slate Tint (`#94A3B8`), and structural metadata rests at Calm Dusk (`#64748B`).

## Typography

The typographic hierarchy solves a dual challenge: rapid visual scanning of scientific metrics and effortless parsing of complex weather narratives.

- **Space Grotesk** anchors primary numerical measures, macro-readouts, and view headers. Its technical geometry complements meteorological charts while maintaining an open, contemporary posture.
- **Manrope** provides humanized legibility for synoptic advisories, automated AI blending commentary, and dense status descriptions.
- **JetBrains Mono** governs precise geospatial coordinates, NWP ensemble runtime indices (e.g., `ECMWF-HRES_00Z`), barometric readouts, and micro-metric labels.

### Micro-Typography Rules
1. Metric cards pair `metric-large` values directly with adjacent, baseline-aligned `metric-unit` tags to maintain tabular rhythm.
2. Coordinate and timestamp strings always render in `label-mono` with uppercase transformation and tabular figures enabled.
3. Section sub-headers pair an uppercase mono eyebrow with a clean `headline-md` title for scannable division of model parameters.

## Layout & Spacing

The dashboard operates on a strict 12-column adaptive fluid grid engineered for multi-monitor forecast rooms, workstation screens, and tactical field tablets.

### Breakpoint Structure
- **Desktop / Forecast Console (>= 1440px):** 12 columns, `gutter-lg` (24px), `margin-lg` (40px). Tri-pane workstation setup: dynamic radar/GIS viewport (7 cols), model blend & divergence controls (3 cols), and stream alerts / synoptic telemetry (2 cols).
- **Tablet / Operational Field (768px - 1439px):** 8 columns, `gutter` (16px), `margin-md` (24px). Dual-stack layout with floating drawer panels for parameter tweaking.
- **Mobile Handset (< 768px):** 4 columns, `gutter` (16px), `margin` (16px). Single-column flow structured around emergency alert cards, high-level radar previews, and glanceable metric tiles.

### Rhythm
Components follow a base 4px spatial factor. Dense data grids leverage `space-xs` (4px) and `space-sm` (8px) gaps. Surface padding within visual cards adheres strictly to `space-md` (16px) or `space-lg` (24px) to preserve calm negative space amidst complex data.

## Elevation & Depth

Visual hierarchy is established using layered atmospheric depth rather than harsh cast shadows. The system utilizes frosted translucent planes, subtle ambient back-glows, and microscopic border rims that capture virtual light.

### Depth Hierarchy
1. **Base Surface (Stratosphere 0):** Hex `#0B111A` with an ambient, broad radial gradient `#0F1D30` positioned top-center to suggest early atmospheric dawn.
2. **Layer 1 (Card Tiles - Troposphere):** Background `rgba(18, 28, 43, 0.65)` layered with `backdrop-filter: blur(20px)` and an ultra-fine border: `1px solid rgba(255, 255, 255, 0.08)`.
3. **Layer 2 (Interactive Floating Modules / Menus):** Background `rgba(24, 38, 58, 0.85)` with `backdrop-filter: blur(28px)`, a soft rim `1px solid rgba(56, 189, 248, 0.20)`, and an ambient tinted drop: `box-shadow: 0 16px 36px -8px rgba(0, 0, 0, 0.5)`.
4. **Layer 3 (Critical Alert Modals & Temporal Sliders):** Background `rgba(15, 23, 36, 0.95)` with `backdrop-filter: blur(32px)`, an outer perimeter glow reflecting the alert status (e.g., Crimson glow: `0 0 32px rgba(244, 63, 94, 0.15)`), and border `1px solid rgba(244, 63, 94, 0.4)`.

### Border Light Treatment
All cards employ an inner highlight using `box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.06)` creating a delicate glass chamfer effect along the upper boundary.

## Shapes

The design system employs a refined curvature profile (`roundedness: 2`) that balances Samsung One UI’s ergonomic softness with the discipline of professional scientific instrumentation.

- **Base Cards & GIS Overlays:** 16px (`rounded-lg`) corner radii convey sleek modern containment without consuming valuable map viewport real estate.
- **Nested Inner Widgets & Sub-cards:** 8px (base radius) preserves structural harmony when grouped inside parent cards.
- **Pills & Status Badges:** Fully rounded (`9999px`) to immediately distinguish dynamic conditions, AI model states, and temporal playback triggers from structural data cards.
- **Interactive Buttons & Form Fields:** 8px corner radius with symmetrical padding, ensuring uniform tactile affordance across input controls.

## Components

### Buttons & Interactive Controls
- **Primary Forecast Blending Button:** Filled in Calm Azure (`#38BDF8`) with dark slate typography (`#0B111A`, font-weight 600). Hover produces an ethereal outer halo (`0 0 20px rgba(56, 189, 248, 0.35)`). Active state applies a subtle scale compress (`0.98`).
- **Secondary / Scientific Toggle:** Frosted translucent backing (`rgba(255, 255, 255, 0.04)`) with an ultra-thin boundary (`rgba(255, 255, 255, 0.12)`). On hover, transition background to `rgba(255, 255, 255, 0.08)`.
- **Temporal Scrubber / Playback Button:** Pill-shaped, semi-opaque dark slate surface housing a high-contrast glyph, flanked by a timeline scrubber with a glowing teal playback head.

### Telemetry Cards & Metric Blocks
- Structured around a glass canvas. Upper section hosts a 12px mono parameter label with an optional sensor-status beacon (4px glowing dot). Center displays the numerical metric in `metric-large`, with its engineering unit (`hPa`, `mm/h`, `knots`, `dBZ`) resting right-aligned or baseline-pinned.
- The footer of each card provides a sparkline or ensemble divergence ribbon showing AI vs. traditional NWP trajectory.

### Status Chips & Alert Badges
- **Normal / Consensus:** Misty Teal border (`rgba(45, 212, 191, 0.3)`), fill (`rgba(45, 212, 191, 0.08)`), text `#2DD4BF`.
- **Advisory / Variance:** Amber border (`rgba(245, 158, 11, 0.3)`), fill (`rgba(245, 158, 11, 0.08)`), text `#F59E0B`.
- **Warning / Cyclone / Flash Flood:** Emergency Crimson border (`rgba(244, 63, 94, 0.4)`), fill (`rgba(244, 63, 94, 0.12)`), text `#FDA4AF`. Accompanied by a calm, synchronized 2-second pulse animation.

### Model Weight Sliders (Hybrid Blending Control)
- Slender 4px track styled in deep slate (`#1E293B`).
- Dual-gradient fill reflecting the blend ratio: Calm Azure (AI weight) merging seamlessly into Misty Teal (NWP weight).
- Slider thumb is a 16px frosted white circular puck with an active center core denoting real-time inference lock.

### Form Inputs & Station Selectors
- Background: `rgba(11, 17, 26, 0.80)`.
- Default border: `1px solid rgba(255, 255, 255, 0.1)`.
- Focus state: Border transitions to `rgba(56, 189, 248, 0.6)` with a soft ambient perimeter glow (`0 0 12px rgba(56, 189, 248, 0.2)`). Text remains crisp Ice Mist (`#E2E8F0`).

### Ensemble Divergence Strip
- A specialized chart component comparing multiple NWP tracks (e.g., GFS, NCUM, ECMWF) against the blended neural forecast. Rendered with faint anti-aliased hairline curves (`1px`, opacity `0.4`), with the blended output highlighted by an azure line (`2px`, opacity `1.0`, subtle ambient drop-glow).